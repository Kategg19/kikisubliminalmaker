;nyquist plug-in
;version 4
;type process
;preview enabled
;name "Subliminal – The Affirmation Breakthrough (Encode)"
;author "Paul Wadsworth - IntraLifestyle.com"
;license "All Rights Reserved"
;debugbutton false
;comment "SAFETY: Contains high-frequency audio energy. Start at low volume. Stop if you notice discomfort, tinnitus, or headaches."
;comment "NOT MEDICAL ADVICE: This is not a medical or psychological treatment or device. No claims of efficacy are made."
;comment "USE AT YOUR OWN RISK: For educational/experimental use by adults only. Author disclaims all liability."
;comment "DO NOT USE while driving, operating machinery, or in situations requiring alertness."
;comment "CONTENT RIGHTS: Ensure you own or have permission for any audio you encode."
;comment "PLATFORM LIMITS: Streaming/MP3 may remove ultrasonic content; results will vary."
;comment "NO AFFILIATION: Not affiliated with or endorsed by Audacity® or The Audacity Team."
;comment "AS-IS: Provided without warranties of any kind, express or implied."

;controls
;control CARRIER "Carrier (Hz)" real "" 17500 16000 19000
;control OFFSET  "Safety offset (Hz)" real "" 80 0 200
;control DEPTH   "Modulation depth" real "" 0.50 0.30 0.80
;control OUTDB   "Output gain (dB)" real "" -6 -24 6

(defun db->lin (db) (power 10 (/ db 20.0)))
(defun bandpass (sig lo hi) (lowpass8 (highpass8 sig lo) hi))
(defun limit-sound (sig lim) (s-min lim (s-max (- lim) sig)))

(defun make-window (sr cf)
  (let* ((nyq (/ sr 2.0))
         (guard 300.0)
         (cf (min (max cf 16000.0) (- nyq guard)))
         (lo (max 15800.0 (- cf 1500.0)))
         (hi (min (- nyq guard) (+ cf 2000.0))))
    (list lo hi cf)))

(defun enc-one (ch)
  (let* ((sr *sound-srate*))
    (if (< sr 44100)
        "Error: Track sample rate must be 44100 Hz or higher."
        (let* ((cf (+ CARRIER OFFSET))
               (win (make-window sr cf))
               (lo (first win))
               (hi (second win))
               (car (hzosc cf))
               (pre (lowpass8 (highpass8 ch 120) 5500))
               (mod (mult (scale DEPTH pre) car))
               (ul  (bandpass mod lo hi))
               (safe (limit-sound ul 0.88)))
          safe))))

(let* ((out (multichan-expand #'enc-one *track*)))
  (if (stringp out) out (mult (db->lin OUTDB) out)))