;nyquist plug-in
;version 4
;type analyze
;name "Subliminal – Verify Encoding (Auto) (The Affirmation Breakthrough)"
;author "Paul Wadsworth - IntraLifestyle.com"
;license "All Rights Reserved"
;debugbutton false
;comment "Automatically checks for ultrasonic AM energy near your chosen carrier. Does not modify audio."
;comment "Tip: Select a few seconds of the ENCODED region before running this."

; -------- Controls (keep simple; ratio does the deciding) --------
;control CARRIER "Expected carrier (Hz)" real "" 17500 16000 19000
;control OFFSET  "Expected offset (Hz)"  real "" 80 0 200
;control LOWW    "Sideband low width (Hz)"  real "" 1500 800 2500
;control HIGHW   "Sideband high width (Hz)" real "" 2000 1200 3000
;control RATIOTH "Detect if Ultrasonic/Audible ratio ≥" real "" 10 5 50

(defun bandpass (sig lo hi) (lowpass8 (highpass8 sig lo) hi))

(let* ((sr *sound-srate*)
       (nyq (/ sr 2.0))
       (guard 300.0)
       (cf (+ CARRIER OFFSET))
       (cf (min (max cf 16000.0) (- nyq guard)))
       (lo (max 15500.0 (- cf LOWW)))
       (hi (min (- nyq guard) (+ cf HIGHW))))
  (if (< sr 44100)
      (format nil "Project rate is ~a Hz. Need ≥ 44100 Hz for ultrasonic encoding." sr)
      (let* ((sel *track*)
             (ultra (bandpass sel lo hi))
             (pk-ultra (peak ultra 10000))
             (audible (lowpass8 (highpass8 sel 20) 12000))
             (pk-aud (peak audible 10000))
             (ratio (if (<= pk-aud 1e-8) 999999 (/ pk-ultra (max 1e-8 pk-aud))))
             (floor 1e-6) ; tiny floor to avoid “silence” false-positives
             (likely (and (> pk-ultra floor) (>= ratio RATIOTH)))
             (status (if likely "LIKELY ENCODED" "NOT DETECTED")))
        (format nil
"Encoding check: ~a
Carrier window center: ~a Hz
Window low/high: ~a Hz / ~a Hz
Peak (ultrasonic band): ~a
Peak (audible <12 kHz): ~a
Ultra/Audible ratio: ~a  (threshold: ≥ ~a)

How to interpret:
• LIKELY ENCODED = strong ultrasonic energy near the carrier relative to audible band.
• NOT DETECTED = ultrasonic band very weak or absent (wrong carrier/offset? lossy file? not encoded?)

Tips:
• Hearing a whistle? Raise Carrier (18–19 kHz), increase Offset (100–150), or reduce Depth (0.40–0.50).
• MP3/streaming may remove ultrasonic band; prefer WAV 44.1 or 48 kHz."
                status cf lo hi pk-ultra pk-aud ratio RATIOTH)))))